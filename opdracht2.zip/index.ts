import { Presenter } from "./presenter.js";

document.addEventListener("DOMContentLoaded", () => {
  new Presenter().load();
});
