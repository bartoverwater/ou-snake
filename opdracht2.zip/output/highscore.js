/** @module highscore */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
/** Database rest api */
const url = "https://snakeou-d554.restdb.io/rest/score";
/**
 * @function request(httpMethod) -> void
 * @desc Helper method to easily create requests. Contains header with the api key
 *
 * @param {string} httpMethod The http request method (GET|POST|PUT|PATCH|DELETE)
 */
function request(httpMethod) {
    return {
        method: httpMethod,
        headers: {
            "cache-control": "no-cache",
            "x-apikey": "600d719f1346a1524ff12d97",
            "content-type": "application/json",
        },
        json: true,
    };
}
/**
 * @desc Retrieves all scores from the database, sorted descending by score.
 * @function getHighscoreList() -> Promise<HighscoreEntry[]>
 * @export
 * @return {Promise<HighscoreEntry[]>} A promise containing all scores from the database.
 */
export function getHighscoreList() {
    return __awaiter(this, void 0, void 0, function* () {
        const response = yield fetch(url + "?sort=score&dir=-1", request("GET"));
        return response.json();
    });
}
/**
 * @desc Inserts new scores into the database. Creates a new entry if the playername is unknown, updates the database entry when the
 * playername is known and the new score is higher than the old score.
 * @function insertScore(newEntry,andThen) => void
 * @export
 * @param {HighscoreEntry} newEntry The new score of the player with playername.
 * @param {function} andThen The function to call when the database is updated.
 */
export function insertScore(newEntry, andThen) {
    fetch(url + '?q={"name": "' + newEntry.name + '"}', request("GET"))
        .then((data) => data.json())
        .then((data) => {
        if (data.length == 0) {
            fetch(url, Object.assign(Object.assign({}, request("POST")), { body: JSON.stringify(newEntry) })).then(andThen);
        }
        else if (data[0].score < newEntry.score) {
            fetch(url + "/" + data[0]._id, Object.assign(Object.assign({}, request("PUT")), { body: JSON.stringify(newEntry) })).then(andThen);
        }
    });
}
